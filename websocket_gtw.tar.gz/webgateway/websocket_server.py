import asyncio
import websockets

async def handler(websocket, path):
    received = await websocket.recv()
    await websocket.send(received)

start_server = websockets.serve(handler, "localhost", 8081)
asyncio.get_event_loop().run_until_complete(start_server)
asyncio.get_event_loop().run_forever()
