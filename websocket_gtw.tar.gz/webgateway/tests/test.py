import os
import sys
import http.server
import threading
import unittest
import requests
import json
import pytest

my_lib_path = os.path.abspath('../webgateway')
sys.path.append(my_lib_path)

from websocket_gtw  import WebSocketGatewayHandler


# Mocking the method would be a better idea
class WebSocketGatewayHandlerStub(WebSocketGatewayHandler):
    def send_msg(self, input_data):
        return input_data.decode()


class WebSocketGatewayHandlerTests(unittest.TestCase):
    url = "http://127.0.0.1:8080/api/ui"
    headers = {'Content-Type': 'application/json'}
    data = json.dumps({'aa':'bb', 'cc':'dd'})

    @classmethod
    def setUpClass(cls):
        # startup the gateway
        cls.gateway = http.server.ThreadingHTTPServer(
            ("127.0.0.1", 8080), WebSocketGatewayHandler)        
        gateway_thread = threading.Thread(target=cls.gateway.serve_forever)
        gateway_thread.daemon = True
        gateway_thread.start()

    @classmethod
    def tearDownClass(cls):
        cls.gateway.shutdown()

    def test_send_valid_json(self):
        response = requests.post(url=self.url, headers=self.headers, data=self.data)
        self.assertEqual(response.text, '{"aa": "bb", "cc": "dd"}')
        self.assertEqual(response.status_code, 201)

    def test_invalid_methods(self):
        response = requests.get(url=self.url, headers=self.headers)
        self.assertEqual(response.status_code, 501)
        response = requests.put(url=self.url, headers=self.headers)
        self.assertEqual(response.status_code, 501)
        response = requests.patch(url=self.url, headers=self.headers)
        self.assertEqual(response.status_code, 501)
        response = requests.delete(url=self.url, headers=self.headers)
        self.assertEqual(response.status_code, 501)

    #@pytest.mark.parametrize('ctype', ['text/*','text/html', 'multipart/form-data'])
    def test_invalid_conten_type(self):
        headers = {'Content-Type': 'text/*'}
        response = requests.post(url=self.url, headers=headers, data=self.data)
        self.assertEqual(response.status_code, 415)

    def test_invalid_json(self):
        data = '{"a": }'
        response = requests.post(url=self.url, headers=self.headers, data=data)
        self.assertEqual(response.status_code, 400)

    def test_empty_data(self):
        data = ''
        response = requests.post(url=self.url, headers=self.headers, data=data)
        self.assertEqual(response.status_code, 400)

    def test_connection_exception(self):
        pass


if __name__ == '__main__':
    unittest.main()
