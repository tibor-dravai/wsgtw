from http.server import BaseHTTPRequestHandler, HTTPServer
from contextlib import closing
import sys
import argparse
import logging
import json
from websocket import create_connection

logging.basicConfig(level=logging.DEBUG,
                    format='%(asctime)s %(levelname)s [%(name)s.%(funcName)s:%(lineno)d] %(message)s')

logger = logging.getLogger(__name__)
#logger.level=logging.INFO

class WebSocketGatewayHandler(BaseHTTPRequestHandler):

    gateway_address = 'localhost:8081'

    def do_POST(self):
        if self.path != '/api/ui':
            return self.send_error(404)
        logger.debug(f'Received headers: {self.headers}')

        if self.headers.get_content_type() != 'application/json':
            return self.send_error(415, 'Expected application/json')

        input_data = self.rfile.read(int(self.headers.get('Content-Length', 0)))
        if not self.validate(input_data):
            return self.send_error(400, 'Invalid JSON data')

        try:
            logger.debug(f'Sending to websocket: {input_data.decode()}')
            received_data = self.send_msg(input_data)
        except ConnectionRefusedError as e:
            logger.error(e)
            return self.send_error(503, 'Websocket is not available.')
        
        logger.debug(f'Received from websocket: {received_data}')
        self.send_response(201)
        self.send_header('Content-type', 'application/json')
        self.end_headers()
        return self.wfile.write(received_data.encode())

    def send_msg(self, input_data):
        with closing(create_connection(f'ws://{self.gateway_address}')) as ws:
            ws.send(input_data)
            return ws.recv()

    def validate(self, input_data):
        # Extend data validation
        # Use stricter exceptions
        try:
            json.loads(input_data.decode())
        except Exception as e:
            logger.debug('Invalid JSON data')
            return False
        return True

    def log_message(self, format, *args):
        logger.debug("%s %s" % (self.address_string(), format%args))


def main(args):
    gatewayserver = HTTPServer((args.gtw_host, args.gtw_port),
                               WebSocketGatewayHandler)
    logger.info(f"Server started http://{args.gtw_host}:{args.gtw_port}/api/ui")
    try:
        gatewayserver.serve_forever()
    except KeyboardInterrupt:
        pass
    gatewayserver.server_close()


if __name__ == '__main__':
    logger.info('Websocket Gateway started.')
    parser = argparse.ArgumentParser(description='Configure websocket gateway')
    parser.add_argument('--gtw-host', default='localhost', help='websocket-gtw hostname or ip address')
    parser.add_argument('--gtw-port', default=8080, type=int, help='websocket-gtw port')

    main(parser.parse_args())

    logger.info('Websocket Gateway stopped.')
