# Websocket Gateway

Websocket Gateway is a piece of code used for forwarding the JSON content
of a request to a websocket without any change of it. The response JSON
is sent back to the user without any change.

## Dependencies

The software depends on the `websocket-client` and the test depends on the
`requests` and `pytest` library. Python 3.8 is supported.

```bash
pip install websocket-client
pip install requests
```

## Usage

Start the gateway:
```bash
python3 ./websocket-server.py
```

For manual testing purposes the `websocket_server.py` can be used. The
server echoss any JSON string to the sender.

Start the gateway:
```bash
python3 ./websocket-server.py
```

Here is an example curl command:
```bash
curl -d '{"key1":"value1", "key2":"value2"}' -H "Content-Type: application/json" -X POST  http://localhost:8080/api/ui
```
Output:
```bash
{"key1":"value1", "key2":"value2"}
```

# Test

Issue the:
```bash
pytest
```
command.
