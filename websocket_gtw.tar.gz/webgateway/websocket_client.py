import websocket

ws = websocket.WebSocket()
ws.connect("ws://localhost:8081")
ws.send("Hello, Server aaaaa")
print(ws.recv())
ws.close()
